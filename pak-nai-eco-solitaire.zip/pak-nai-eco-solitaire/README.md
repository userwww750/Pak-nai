# Pak Nai Eco-Solitaire

A Pen created on CodePen.

Original URL: [https://codepen.io/sss-ss-s/pen/gbWjJmO](https://codepen.io/sss-ss-s/pen/gbWjJmO).

A fun attempt at making a full-featured solitaire game in vanilla JS. No jQuery. No frameworks.