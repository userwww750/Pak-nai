const CATEGORIES = {
  species: { label: "Species", color: "#0f766e" },
  threats: { label: "Current Threats", color: "#b45309" },
  impacts: { label: "Impact of Threats", color: "#be123c" },
  donts:   { label: "Things should NOT do in habitat", color: "#4338ca" }
};

// Built-in clean vector illustrations if local spc-1.jpg..spc-6.jpg are not present yet
const FALLBACK_SVGS = {
  "spc-1": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#e6f4f1"/><path d="M32 62 C32 32, 88 32, 88 62 C88 74, 78 80, 60 80 C42 80, 32 74, 32 62 Z" fill="#6b5b45"/><path d="M38 66 L82 66 L76 84 L44 84 Z" fill="#827057"/><line x1="60" y1="84" x2="60" y2="112" stroke="#574936" stroke-width="4" stroke-linecap="round"/><circle cx="46" cy="52" r="2.5" fill="#1e293b"/><circle cx="74" cy="52" r="2.5" fill="#1e293b"/></svg>`,
  "spc-2": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#fef3c7"/><ellipse cx="62" cy="72" rx="34" ry="15" fill="#64748b"/><path d="M28 72 L14 62 L16 82 Z" fill="#475569"/><circle cx="84" cy="56" r="7" fill="#f8fafc" stroke="#334155" stroke-width="2"/><circle cx="85" cy="56" r="3" fill="#0f172a"/><circle cx="74" cy="57" r="6" fill="#f8fafc" stroke="#334155" stroke-width="2"/><circle cx="75" cy="57" r="2.5" fill="#0f172a"/><path d="M68 78 Q62 92 74 90" fill="none" stroke="#475569" stroke-width="4" stroke-linecap="round"/></svg>`,
  "spc-3": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#ffe4e6"/><ellipse cx="64" cy="68" rx="22" ry="16" fill="#e11d48"/><path d="M44 64 C20 44, 16 78, 44 74 Z" fill="#fb7185"/><path d="M44 64 C26 54, 24 68, 44 68 Z" fill="#fecdd3"/><line x1="56" y1="53" x2="54" y2="43" stroke="#9f1239" stroke-width="2.5"/><line x1="72" y1="53" x2="74" y2="43" stroke="#9f1239" stroke-width="2.5"/><circle cx="54" cy="42" r="2.5" fill="#0f172a"/><circle cx="74" cy="42" r="2.5" fill="#0f172a"/><path d="M50 82 L42 96 M62 84 L60 98 M76 82 L84 96" stroke="#9f1239" stroke-width="3" stroke-linecap="round"/></svg>`,
  "spc-4": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#e0f2fe"/><ellipse cx="54" cy="68" rx="24" ry="15" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5"/><path d="M72 62 Q82 40 74 32" fill="none" stroke="#ffffff" stroke-width="8" stroke-linecap="round"/><circle cx="74" cy="32" r="7" fill="#1e293b"/><path d="M79 33 L104 42 C108 44, 106 49, 101 47 L78 37 Z" fill="#334155"/><line x1="50" y1="82" x2="48" y2="104" stroke="#1e293b" stroke-width="3"/><line x1="60" y1="82" x2="62" y2="104" stroke="#1e293b" stroke-width="3"/></svg>`,
  "spc-5": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#f1f5f9"/><path d="M36 86 C26 60, 44 26, 66 26 C88 26, 96 64, 82 88 C70 98, 46 96, 36 86 Z" fill="#94a3b8" stroke="#475569" stroke-width="2"/><path d="M44 80 C38 62, 50 38, 65 38 C80 38, 84 64, 74 82 C66 88, 50 88, 44 80 Z" fill="#cbd5e1"/><ellipse cx="62" cy="64" rx="11" ry="15" fill="#fef08a"/></svg>`,
  "spc-6": `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><rect width="120" height="120" fill="#ecfdf5"/><ellipse cx="54" cy="66" rx="22" ry="14" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5"/><path d="M70 60 Q82 42 74 30" fill="none" stroke="#ffffff" stroke-width="7" stroke-linecap="round"/><circle cx="74" cy="29" r="6" fill="#ffffff" stroke="#cbd5e1" stroke-width="1.5"/><polygon points="79,27 98,30 79,32" fill="#1e293b"/><line x1="50" y1="79" x2="48" y2="100" stroke="#0f172a" stroke-width="2.5"/><line x1="60" y1="79" x2="62" y2="100" stroke="#0f172a" stroke-width="2.5"/><path d="M42 101 L53 101 M57 101 L68 101" stroke="#eab308" stroke-width="3.5" stroke-linecap="round"/></svg>`
};

const DECK_DATA = [
  // 1. Species (6) — Photo + Bilingual Name Only
  {
    id: "spc-1",
    cat: "species",
    enName: "Chinese Horseshoe Crab",
    zhName: "中國鱟",
    title: "Chinese Horseshoe Crab (中國鱟)",
    photo: "spc-1.jpg",
    note: "Fun Fact: The blood of the horseshoe crab is bright blue. It can be used to test the safety of vaccines."
  },
  {
    id: "spc-2",
    cat: "species",
    enName: "Mudskipper",
    zhName: "彈塗魚",
    title: "Mudskipper (彈塗魚)",
    photo: "spc-2.jpg",
    note: "Fun Fact: Mudskippers fill their mouths with water before coming ashore so they can swallow their prey."
  },
  {
    id: "spc-3",
    cat: "species",
    enName: "Fiddler Crab",
    zhName: "招潮蟹",
    title: "Fiddler Crab (招潮蟹)",
    photo: "spc-3.jpg",
    note: "Fun Fact: When a male crab loses its large claw in a fight, its original small claw will molt into a new one. Some lazy male crabs will even cheat by growing a hollow and lighter claw to scare away their opponents."
  },
  {
    id: "spc-4",
    cat: "species",
    enName: "Black-faced Spoonbill",
    zhName: "黑臉琵鷺",
    title: "Black-faced Spoonbill (黑臉琵鷺)",
    photo: "spc-4.jpg",
    note: "Every winter, hundreds visit Deep Bay and Pak Nai to sweep shallow waters for small fish and shrimp."
  },
  {
    id: "spc-5",
    cat: "species",
    enName: "Hong Kong Oyster",
    zhName: "香港巨牡蠣",
    title: "Hong Kong Oyster (香港巨牡蠣)",
    photo: "spc-5.jpg",
    note: "A single adult oyster filters up to 50 gallons of water a day, keeping Deep Bay clear and creating shelter for small fish."
  },
  {
    id: "spc-6",
    cat: "species",
    enName: "Little Egret",
    zhName: "小白鷺",
    title: "Little Egret (小白鷺)",
    photo: "spc-6.jpg",
    note: "Fun Fact: Little egret spreads one wing, casting a shadow on the water. This deceives the small fish, making them think they have found a safe haven, but they end up falling into the egret's trap."
  },

  // 2. Current Threats (6)
  {
    id: "thr-1",
    cat: "threats",
    title: 'Abandoned Oyster Nets ("Ghost Gear")',
    subtitle: "Discarded nylon mesh and poles left from old oyster farming.",
    note: "Loose netting sits across the intertidal zone, acting as hidden traps long after farming stops."
  },
  {
    id: "thr-2",
    cat: "threats",
    title: "Invasive Smooth Cordgrass (Spartina)",
    subtitle: "Fast-spreading non-native grass taking over open mud.",
    note: "Spartina forms dense root mats that crowd out native seagrass and shrink open feeding grounds."
  },
  {
    id: "thr-3",
    cat: "threats",
    title: "Heavy Weekend Clam-Digging Crowds",
    subtitle: "Large numbers of recreational visitors turning over the mudflat.",
    note: "Intense weekend foot traffic and digging repeatedly churn up delicate surface sediment layers."
  },
  {
    id: "thr-4",
    cat: "threats",
    title: "Floating Marine Litter & Microplastics",
    subtitle: "Plastic bags, foam, and debris washed in by Deep Bay tides.",
    note: "Tidal currents trap coastal trash along Pak Nai’s shoreline, polluting mudflat sediments."
  },
  {
    id: "thr-5",
    cat: "threats",
    title: "Coastal Reclamation & Nearby Development",
    subtitle: "Urban construction and shoreline hardening along Deep Bay.",
    note: "Replacing natural mud edges with concrete seawalls shrinks the intertidal zone where wildlife feeds and breeds."
  },
  {
    id: "thr-6",
    cat: "threats",
    title: "Agricultural & Domestic Runoff",
    subtitle: "Wastewater and excess nutrients draining into Deep Bay streams.",
    note: "Nutrient runoff triggers algal blooms that deplete dissolved oxygen in shallow tidal pools."
  },

  // 3. Impact of Threats (6)
  {
    id: "imp-1",
    cat: "impacts",
    title: "Entanglement of Juvenile Horseshoe Crabs",
    subtitle: "Young crabs get trapped in ghost nets and starve or injure limbs.",
    note: "Because juveniles cannot free themselves from tangled mesh, ghost gear directly reduces future breeding populations."
  },
  {
    id: "imp-2",
    cat: "impacts",
    title: "Loss of Shorebird Feeding Grounds",
    subtitle: "Invasive grass blocks birds from probing soft mud for food.",
    note: "Migratory birds like the Black-faced Spoonbill lose vital energy reserves needed for their seasonal flight."
  },
  {
    id: "imp-3",
    cat: "impacts",
    title: 'Squeezed Intertidal Habitat ("Coastal Squeeze")',
    subtitle: "Rising tides trap mudflats against rigid seawalls, shrinking beach width.",
    note: "When sea levels rise against hardened shorelines, intertidal zones cannot retreat inland and gradually disappear."
  },
  {
    id: "imp-4",
    cat: "impacts",
    title: "Microplastic Ingestion in Filter Feeders",
    subtitle: "Oysters and clams absorb tiny plastic particles while filtering water.",
    note: "Pollutants build up inside shellfish and pass up the food chain to birds and marine predators."
  },
  {
    id: "imp-5",
    cat: "impacts",
    title: "Uprooted & Smothered Seagrass Meadows",
    subtitle: "Digging and silt disturbance destroy vital underwater plant beds.",
    note: "When seagrass dies off, juvenile fish and crabs lose their primary camouflage from predators."
  },
  {
    id: "imp-6",
    cat: "impacts",
    title: 'Hypoxia (Low-Oxygen "Dead Zones")',
    subtitle: "Decaying algae strips oxygen from shallow mudflat water.",
    note: "Low oxygen forces burrowing worms and clams to the surface, causing mass die-offs during warm weather."
  },

  // 4. Things should NOT do in habitat (6)
  {
    id: "dnt-1",
    cat: "donts",
    title: "Digging Clams with Shovels or Rakes",
    subtitle: "Turning over mud to harvest shellfish during a field visit.",
    note: "Digging tears up seagrass roots and destroys nursery beds needed by young horseshoe crabs."
  },
  {
    id: "dnt-2",
    cat: "donts",
    title: "Taking Shells Home as Souvenirs",
    subtitle: "Collecting empty shells from the beach instead of leaving them behind.",
    note: "Empty shells provide essential shelter for hermit crabs and hard surfaces for baby oysters to attach."
  },
  {
    id: "dnt-3",
    cat: "donts",
    title: "Stepping onto Green Seagrass Patches",
    subtitle: "Walking directly across vegetated mud instead of bare sand paths.",
    note: "Seagrass stabilizes the mud and shelters small fish; stepping on it snaps fragile shoots and roots."
  },
  {
    id: "dnt-4",
    cat: "donts",
    title: "Lifting Horseshoe Crabs by the Tail",
    subtitle: "Picking up or chasing juvenile crabs on the mudflat.",
    note: "Lifting a horseshoe crab by its tail spine (telson) can permanently injure it—they only use it to flip over."
  },
  {
    id: "dnt-5",
    cat: "donts",
    title: "Driving Bicycles or Vehicles onto the Mudflat",
    subtitle: "Riding wheels across soft intertidal sand and mud.",
    note: "Wind and rising tides quickly pull unsecured beach litter into Deep Bay, turning it into marine debris."
  },
  {
    id: "dnt-6",
    cat: "donts",
    title: "Shouting or Running Near Feeding Birds",
    subtitle: "Making loud noises or approaching resting waterbirds closely.",
    note: "Startling migratory birds wastes critical energy they need to survive winter and migrate north."
  }
];

// Game State
let state = {
  stock: [],
  waste: [],
  tableau: [[], [], [], [], [], [], []],
  foundations: { species: [], threats: [], impacts: [], donts: [] },
  moves: 0,
  seconds: 0,
  timerId: null,
  dragSource: null
};

// Shuffle helper
function shuffle(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

// Start / Reset Game
function initGame() {
  clearInterval(state.timerId);
  const deck = shuffle(DECK_DATA).map(c => ({ ...c, faceUp: false }));

  state.tableau = [[], [], [], [], [], [], []];
  // Classic Solitaire deal: 1..6 cards across columns 0..5 (21 cards), 3 cards in Stock = 24 cards
  let idx = 0;
  for (let col = 0; col < 6; col++) {
    for (let row = 0; row <= col; row++) {
      const card = deck[idx++];
      if (row === col) card.faceUp = true;
      state.tableau[col].push(card);
    }
  }
  // Remaining 3 cards go to Stock
  state.stock = deck.slice(idx);
  state.waste = [];
  state.foundations = { species: [], threats: [], impacts: [], donts: [] };
  state.moves = 0;
  state.seconds = 0;

  state.timerId = setInterval(() => {
    state.seconds++;
    document.getElementById("timer").textContent = formatTime(state.seconds);
  }, 1000);

  renderBoard();
}

function formatTime(sec) {
  const m = String(Math.floor(sec / 60)).padStart(2, "0");
  const s = String(sec % 60).padStart(2, "0");
  return `${m}:${s}`;
}

function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toast.classList.remove("show"), 2200);
}

// Build Card DOM Element
function createCardElement(card, sourceInfo, isPlayable) {
  const el = document.createElement("div");
  el.className = "card " + (card.faceUp ? "face-up" : "face-down");

  if (!card.faceUp) {
    el.innerHTML = `<div class="card-back-emblem">Pak Nai</div>`;
    return el;
  }

  if (isPlayable) {
    el.classList.add("playable");
    el.draggable = true;
  } else {
    el.classList.add("locked");
  }

  // Species Card: Photo + Bilingual Name Only (No corner symbols or subtitles)
  if (card.cat === "species") {
    el.classList.add("species-card");
    const svgFallback = FALLBACK_SVGS[card.id] || "";
    const encodedSvg = "data:image/svg+xml;utf8," + encodeURIComponent(svgFallback);

    el.innerHTML = `
      <div class="species-photo-frame">
        <img src="${card.photo}" alt="${card.enName}" onerror="this.onerror=null;this.src='${encodedSvg}';">
      </div>
      <div class="species-name-box">
        <div class="species-en">${card.enName}</div>
        <div class="species-zh">${card.zhName}</div>
      </div>
    `;
  } else {
    // Text Card: Title + Subtitle Only (Top corner blank for deduction)
    el.innerHTML = `
      <div class="card-top-spacer"></div>
      <div class="card-text-body">
        <div class="card-title">${card.title}</div>
        <div class="card-divider"></div>
        <div class="card-subtitle">${card.subtitle}</div>
      </div>
    `;
  }

  if (isPlayable) {
    el.addEventListener("dragstart", (e) => {
      state.dragSource = sourceInfo;
      el.classList.add("dragging");
      e.dataTransfer.setData("text/plain", card.id);
    });

    el.addEventListener("dragend", () => {
      el.classList.remove("dragging");
      state.dragSource = null;
    });

    // Double-click shortcut to auto-sort into its matching foundation pile
    el.addEventListener("dblclick", () => {
      attemptFoundationMove(sourceInfo, card.cat, el);
    });
  }

  return el;
}

// Render Entire Board
function renderBoard() {
  // Update HUD
  const totalSorted = Object.values(state.foundations).reduce((acc, arr) => acc + arr.length, 0);
  document.getElementById("sorted-count").textContent = `${totalSorted} / 24`;
  document.getElementById("move-count").textContent = state.moves;
  document.getElementById("timer").textContent = formatTime(state.seconds);

  // Stock Pile
  const stockEl = document.getElementById("stock-pile");
  stockEl.innerHTML = `
    <div class="slot-label">${state.stock.length > 0 ? "Draw Card" : "Recycle"}</div>
    <div class="slot-sub">${state.stock.length} left</div>
  `;
  if (state.stock.length > 0) {
    const backCard = document.createElement("div");
    backCard.className = "card face-down";
    backCard.style.top = "-2px";
    backCard.style.left = "-2px";
    backCard.style.pointerEvents = "none";
    backCard.innerHTML = `<div class="card-back-emblem">Pak Nai</div>`;
    stockEl.appendChild(backCard);
  }

  // Waste Pile
  const wasteEl = document.getElementById("waste-pile");
  wasteEl.innerHTML = `
    <div class="slot-label">Waste</div>
    <div class="slot-sub">Current Card</div>
  `;
  if (state.waste.length > 0) {
    const topWaste = state.waste[state.waste.length - 1];
    const cardEl = createCardElement(topWaste, { type: "waste" }, true);
    cardEl.style.top = "-2px";
    cardEl.style.left = "-2px";
    wasteEl.appendChild(cardEl);
  }

  // 4 Foundation Piles
  for (const cat of Object.keys(CATEGORIES)) {
    const pile = state.foundations[cat];
    document.getElementById(`cnt-${cat}`).textContent = `${pile.length} / 6`;
    const container = document.getElementById(`fc-${cat}`);
    container.innerHTML = "";
    if (pile.length > 0) {
      const topCard = pile[pile.length - 1];
      const mini = document.createElement("div");
      mini.className = "foundation-top-card";
      mini.innerHTML = `
        <div class="ft-title">${topCard.title}</div>
        ${topCard.subtitle ? `<div class="ft-sub">${topCard.subtitle}</div>` : ""}
      `;
      container.appendChild(mini);
    }
  }

  // 7 Tableau Columns
  const cols = document.querySelectorAll(".tableau-col");
  cols.forEach((colEl, colIdx) => {
    colEl.innerHTML = "";
    const cards = state.tableau[colIdx];
    let offsetY = 0;

    cards.forEach((card, cardIdx) => {
      const isTop = cardIdx === cards.length - 1;
      const cardEl = createCardElement(
        card,
        { type: "tableau", col: colIdx, index: cardIdx },
        card.faceUp && isTop
      );
      cardEl.style.top = `${offsetY}px`;
      cardEl.style.zIndex = cardIdx + 1;
      colEl.appendChild(cardEl);

      offsetY += card.faceUp ? 36 : 22;
    });

    colEl.style.height = `${Math.max(194, offsetY + 165)}px`;
  });
}

// Stock Click: Draw or Recycle
document.getElementById("stock-pile").addEventListener("click", () => {
  if (state.stock.length > 0) {
    const card = state.stock.pop();
    card.faceUp = true;
    state.waste.push(card);
    state.moves++;
    renderBoard();
  } else if (state.waste.length > 0) {
    state.stock = state.waste.reverse().map(c => ({ ...c, faceUp: false }));
    state.waste = [];
    state.moves++;
    showToast("Recycled Waste pile back into Stock");
    renderBoard();
  }
});

// Remove card from source and flip newly exposed tableau card
function popFromSource(source) {
  let card = null;
  if (source.type === "waste") {
    card = state.waste.pop();
  } else if (source.type === "tableau") {
    const col = state.tableau[source.col];
    card = col.pop();
    if (col.length > 0 && !col[col.length - 1].faceUp) {
      col[col.length - 1].faceUp = true;
    }
  }
  return card;
}

function peekFromSource(source) {
  if (!source) return null;
  if (source.type === "waste") return state.waste[state.waste.length - 1];
  if (source.type === "tableau") {
    const col = state.tableau[source.col];
    return col[col.length - 1];
  }
  return null;
}

// Check & Execute Move to Foundation Pile
function attemptFoundationMove(source, targetCat, cardEl) {
  const card = peekFromSource(source);
  if (!card) return;

  if (card.cat === targetCat) {
    popFromSource(source);
    state.foundations[targetCat].push(card);
    state.moves++;
    renderBoard();
    openFieldNote(card);
  } else {
    state.moves++;
    renderBoard();
    if (cardEl) {
      cardEl.classList.add("shake");
      setTimeout(() => cardEl.classList.remove("shake"), 400);
    }
    showToast(`Not quite! That card does not belong in "${CATEGORIES[targetCat].label}".`);
  }
}

// Setup Drag & Drop on Foundation Slots
document.querySelectorAll(".foundation-slot").forEach(slot => {
  const targetCat = slot.dataset.cat;

  slot.addEventListener("dragover", (e) => {
    e.preventDefault();
    slot.classList.add("drag-over");
  });

  slot.addEventListener("dragleave", () => {
    slot.classList.remove("drag-over");
  });

  slot.addEventListener("drop", (e) => {
    e.preventDefault();
    slot.classList.remove("drag-over");
    if (!state.dragSource) return;
    attemptFoundationMove(state.dragSource, targetCat, slot);
  });
});

// Setup Drag & Drop on Tableau Columns (Allows moving top card between columns to uncover hidden cards)
document.querySelectorAll(".tableau-col").forEach(colEl => {
  const targetCol = Number(colEl.dataset.col);

  colEl.addEventListener("dragover", (e) => {
    e.preventDefault();
    colEl.classList.add("drag-over");
  });

  colEl.addEventListener("dragleave", () => {
    colEl.classList.remove("drag-over");
  });

  colEl.addEventListener("drop", (e) => {
    e.preventDefault();
    colEl.classList.remove("drag-over");
    if (!state.dragSource) return;
    if (state.dragSource.type === "tableau" && state.dragSource.col === targetCol) return;

    const card = popFromSource(state.dragSource);
    if (card) {
      state.tableau[targetCol].push(card);
      state.moves++;
      renderBoard();
    }
  });
});

// Field Note Pop-up Modal
function openFieldNote(card) {
  const catInfo = CATEGORIES[card.cat];
  const modal = document.getElementById("note-modal");
  const modalCard = modal.querySelector(".modal-card");
  const badge = document.getElementById("m-badge");

  modalCard.style.borderTopColor = catInfo.color;
  badge.style.background = catInfo.color;
  badge.textContent = `Sorted into: ${catInfo.label}`;

  document.getElementById("m-title").textContent = card.title;
  document.getElementById("m-note").textContent = card.note;
  modal.classList.add("open");
}

document.getElementById("btn-close-note").addEventListener("click", () => {
  document.getElementById("note-modal").classList.remove("open");
  checkVictory();
});

// Check Victory Condition
function checkVictory() {
  const totalSorted = Object.values(state.foundations).reduce((acc, arr) => acc + arr.length, 0);
  if (totalSorted === 24) {
    clearInterval(state.timerId);
    document.getElementById("win-stats").textContent =
      `You classified all 24 Pak Nai ecology cards in ${state.moves} moves and ${formatTime(state.seconds)}!`;

    const list = document.getElementById("win-summary-list");
    list.innerHTML = "";
    for (const [catKey, cards] of Object.entries(state.foundations)) {
      const catInfo = CATEGORIES[catKey];
      cards.forEach(c => {
        const item = document.createElement("div");
        item.className = "win-item";
        item.style.borderLeftColor = catInfo.color;
        item.innerHTML = `<strong>[${catInfo.label}] ${c.title}</strong>${c.note}`;
        list.appendChild(item);
      });
    }
    document.getElementById("win-modal").classList.add("open");
  }
}

// Help & Reset Controls
document.getElementById("btn-help").addEventListener("click", () => {
  document.getElementById("help-modal").classList.add("open");
});
document.getElementById("btn-close-help").addEventListener("click", () => {
  document.getElementById("help-modal").classList.remove("open");
});
document.getElementById("btn-new").addEventListener("click", initGame);
document.getElementById("btn-play-again").addEventListener("click", () => {
  document.getElementById("win-modal").classList.remove("open");
  initGame();
});

// Boot Game
initGame();